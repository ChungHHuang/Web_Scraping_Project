# filter - Take subsets of rows
df %>% filter(colname %in% c(1, 4) | colname=="name")
df %>% filter(!is.na(colname))

# select - Take subsets of columns
df %>% select(col1, col2, -col3, ...)
df %>% select(1)            # Select the first column
select(
	starts_with(x, ignore.case=T)   # Pick column names starting with x
	ends_with(x, ignore.case=T)     # Pick column names ending with x
	contains(x, ignore.case=T)      # Pick column names containing x
	matches(x, ignore.case=T)       # Pick columns whose names match x, where x is a regular expression.
	one_of(name_1, name_2, ..., name_n) # Pick columns that have any of the names in the list
	new-column-name = original-column-name  # Rename a column
	)

# arrange - Reorder rows
df %>% arrange(colname)         # sort in ascending order
df %>% arrange(desc(colname))   # sort in descending order

# mutate/transmute - Add or replace columns
df %>% mutate(new_col = colname*+-/2)   # Create a new column by deriving its value from an old column
df %>% transmute(new_col = 2 * colname) # Only return the new columns

# summarise - Compute aggregate values
df %>% summarise(total = sum(value)) 	
min(), max(), mean(), sum(), sd() and median()
n()                                     # Returns the number of observations
distinct()                              # Neglect the duplicate row
n_distinct(colname)                     # Returns the number of unique values in the column 
first(column) or last(colname)          # Returns the first or last observations in the column
nth(colname, n)                         # Returns the nth observation in column
count()									# same as summarise(n= n())
# joins - Methods to combine multiple data frames
inner_join(df1, df2, by = c("colname","colname2"))
left_join(df1, df2, by = "colname")
full_join(df1, df2, by = "colname")
semi_join(df1, df2, by = "colname")     # Similar to inner_join(). The difference is that it retains only the columns in the left data frame 
anit_join(df1, df2, by = "colname")     # Similar to semi_join(). However, it retains only the rows that do not have a match in the right data frame

# group_by - Grouping operations that “split-apply-combine”
df %>% group_by(colname)
group_by(df,colname1,colname2)

#####################################################################################################################################
# ggplot2
g = ggplot(data = df, aes(x = col1, y = col2))

g + geom_<geom type>()
Types: point, histogram, bar, Line graphs, boxplots,
	   smooth, freqpoly, density, bin2d, density2d, polygon (map),
	   violin, dotplot, col
#col is similar to bar but col takes two inputs (x,y) 
geom_smooth(method = "lm", se = F)  # linear model

# aes
aes(type = col, size = int)
Types: color, size, shape, alpha, fill  # Distingush data by color ...
aes(x = reorder(col1,col2, mean/median), y=col2) 

# Faceting
facet_grid(. ~ categorical col)     # Subplots for different categories
facet_grid(categorical col ~ .)
facet_wrap( ~ categorical col)

# Barplot
ggplot(data = df, aes(x = col1)) + 
	geom_bar(aes(fill = col2), position = "fill"/"dodge","jitter")
										  ^^^^bar^^^^^^^ ^^point^

# Histograms
g + geom_histogram(binwidth = 1, position = position_stack(reverse=TRUE))       # Default: range/30
  + coord_cartesian(xlim = c(55, 70))   # Set x limit

# Saving plots
ggsave("my-plot.pdf", width = 6, height = 6)
ggsave("my-plot.png", width = 6, height = 6)

other geoms
facets with facet_grid(...) or facet_wrap(...) 
stats with stat_<transformation>(...)
scales with scale_<aesthetic>_<type>(...)
coordinate systems with coord_<system>(...)
themes with theme(...)
titles and labels with ggtitle(...) or labs(...)


## Customizing Graphics ##
theme_update(plot.title = element_text(hjust = 0.5))        # Put title at the center
# Title
ggtitle("Population of Texas Counties")
# Coordinate Systems
g$coordinates
coord_type()
Types: cartesian, polar, flip, fixed(ratio = ...), 
	   trans(x="log10",y="log10"), map
xlim = c(xmin,xmax), ylim = c(ymin,ymax)

# Scales
scale_aesthetic_name()
scale_color_gradient(low = "red", high = "yellow")
scale_size_area()
scale_shape_manual(values = c(0, 15, 1, 16, 3))

library(RColorBrewer)
scale_fill_brewer(palette = "OrRd") #Pg 52

# Themes
theme_grey()
theme_bw()

# Axis Labels
xlab(" "), ylab(" ")

# Legends
theme(legend.position ="bottom/top/left/right")
guides(color = "colorbar/legend/none")
name = "legend_name"
labels = c("label1","label2", ...)




























