?func 						# R Doc
# Data type
class()						# = type() in Py
m %% n 						# = % in Py
m %/% n 					# = // in Py
&|							# and , or don't work
as.type()					# conversion operators (not mutating) ex. as.integer(), as.character()
c(1,2,3,4)					# Create vector (c stands for combine)
c(1:4)						# Everything in a vector must be same type
c(vec1,vec2)				# Concatnate two vectors
seq(from, to, by)			# Create vector by = step
seq(from, to, length)		# Specify the length of the seq
sample(c('A', 'B'), size=10, replace=TRUE)	# Draw sample randomly from a vector (replace = put sample back after getting the sample)
rep(value/vec,value2/vec2)	#
letters[1:5]				# lower case letter
LETTERS[1:5] 				# Upper case letter

#### Missing data ##### 
# Show table or visualization of missing data
summary(df)
library(VIM)
VIM::aggr(df)
# How many rows contain at least one NA?
complete.cases(df)


### String
cat(str1,str2) 				# = str1 + str2 in Py
nchar()						# Count the number of characters
strsplit(vec,split=' ')		# Split the elements of a character vector
paste(vec1,vec2,sep=' ',collapse=',')	# Concatenate strings (collapse makes the vec into a string)
paste0(vec1,vec2)			# = paste() but sep = ''
substr(vec,begin,end)		# Create substrings of a character vector
gsub(str1,str2,vec)			# Replace str1 in vec with str2 
grep(str,vec)				# Find str in vec then return the index

### Vector slicing
x[seq(1, 4, by=2)]			# Slice x
x[c(T,F,T,F)]				# Get the first and third element
x[c(-2, -4)]				# all elements except 2 and 4
names(vec) = letter[]		# Naming vector

# Matrix
matrix(vec,row,col)			# Loop through column then row (If byrow=T, then loop through the row then columns)
cbind(vec1,vec2,...)		# Create a matrix by concatenating column vectors 
rbind(vec1,vec2,...)		#								   row
mat[c(1,4),c(2,3)]			# Return the second and third element in row 1 and 4
my_mat[,n,drop= F]			# Keep the matrix or data frame structure 

# Array
array(m:n, c(x, y, z))		# Make an array

### Work for vec and mat #####
vec1 + vec2 				# Elementwise adding (When the length of the vectors is different, 
	><$						# R repeats the shorter vector to match the length of the longer vector)

# Aggregating func 
mean,sd,length,summary
max(vec,na.rm = TRUE)		# Ignore NA
##############################

# Data Frame
data.frame(vec1,vec2,..., row.names = vec, col.name = vec)
colnames(df) (= vec)		# Find column name (or assign new names)
rownames(df)				# 	   row
nrow(df)					
ncol(df)
df$column_name				# Return the column name  # citydf[citydf$temp > 76,]
dim(df)						# Dimension of the data frame
head(df, n)					# = .head() in Py
str(df)						# The structure of the df
summary(df)					# Column-wise summary statistics
order(df, decreasing=TRUE)	# Gives the order of the elements of a vector Ex. citydf[order(citydf$temp, decreasing=TRUE),]
unique(df$column_name)      # Return the non-repeat elements
write.table(df, file='df.csv', sep=',', row.names=F) # row.names=F if the index is not needed
write.csv(df, file='df.csv', row.names=F)
read.csv('df.csv')			
read.table('df.csv', header=T, sep=',') 
read.xlsx("fileName.xlsx", sheetIndex=1)
read.dta("file_name.dta")
read.spss("file_name.sav")
read.xport("file_name.xpt")

# List
list(A='a', B='b',C=9.50)	# Create a list
list_name$column_name = Null# Remove column

# Factor 
factor(vec)					# Create a factor
level(fac) (= vev2)			# Check the level in fac (Change name of the level)

# Apply
sapply(vec, func)			# Implement a function f on each element of a vector v (return a vector)
lapply(vec, func)			# Similar to sapply but return a list
apply(vec,func)				# manipulate matrices
apply(mat, 1, sum)			# across row
apply(mat, 2, sum)			# across col

# Control statement
ifelse(lv, v1, v2) 			# lv = logical vec, v1 if true, v2 otherwise. (v2 can be nested ifelse)
switch(obj,cases = actions)	# 
'''
if (condition) {				Choice = 'A'								
  actions  						switch(Choice,																													
} else if (condition) {				'A' = Grade[Grade>=90],
  actions 							'B' = Grade[Grade < 90 & Grade >= 80],
} else {   							'C' = Grade[Grade < 80 & Grade >= 70])
  action
}
'''

# Loop
for (variable in vector){body} 	
while (terminating condition) {body}

# Data transformation
split(df, df$column_name)
unsplit(split_df, df$column_name)

# Stat
rnorm(n)					# default mean 0 and standard deviation 1
runif(n)					# default min 0 and max 1
rbinom(n)					# 













