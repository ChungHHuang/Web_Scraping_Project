# Linear model
model = lm(Y ~ X - 1, data = df) 			# Simple LR (-1 to make intercept to 0)
model = lm(Y ~ ., data = df)				# Multi LR

summary(model) 								# All the summary information for the model in question.
confint(model) 								#Creating 95% confidence intervals for the model coefficients.

#Normality
qqnorm(model$residuals)
qqline(model$residuals)

plot(model)									# Using the built-in plot() function to visualize the residual plots.

# Predicting New Observations
newdata = data.frame(colname = c(...,...,...))
predict(model, newdata) 						  # Return predictions	
predict(model, newdata, interval = "confidence")  # Construct confidence intervals
predict(model, newdata, interval = "prediction")  # Construct prediction invervals

#####The Box-Cox Transformation#####
bc = boxCox(model) #Automatically plots a 95% confidence interval for the lambda
                   #value that maximizes the likelihhood of transforming to
                   #normality.

lambda = bc$x[which(bc$y == max(bc$y))] #Extracting the best lambda value.
dist.bc = (cars$dist^lambda - 1)/lambda #Applying the Box-Cox transformation.