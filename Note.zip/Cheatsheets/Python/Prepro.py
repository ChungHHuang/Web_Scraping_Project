from sklearn.preprocessing import StandardScaler, MinMaxScaler, MaxAbsScaler 


# Normalization of the Features
# Scale numeric columns
scaler = StandardScaler()
#scaler = preprocessing.RobustScaler()
full_data[num_cols] = scaler.fit_transform(full_data[num_cols])
# Log transform
df_train.SalePrice = np.log1p(df_train.SalePrice)


# Show value counts
for name in final.columns:
    print(final[name].value_counts())

# Show missing percentage
total = full_data.isnull().sum().sort_values(ascending=False)
percent = (full_data.isnull().sum()/full_data.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
missing_data.head(35)

# Remove outliers
z = np.abs(zscore(train_set[get_numeric_columns(train_set)]))
row, col = np.where(z > 4)
df = pd.DataFrame({"row": row, "col": col})
rows_count = df.groupby(['row']).count()

outliers = rows_count[rows_count.col > 2].index
train_set.drop(outliers, inplace=True)

# Missing data
missingRows = df.isnull().any(axis=1)
missingCols = df.isnull().any(axis=0)
df = df[~missingRows]  # remove rows with missingness

# Transform ordinal column to string
df.column = df.column.astype(str)

# Check distribution of numerical values 
plt.figure(figsize=(8,6))
b = sns.distplot(df.column, fit=norm)
b.tick_params(labelsize=12)
b.set_xlabel("xlabel",fontsize=14)

# Box cox 
num_cols = full_data.dtypes[full_data.dtypes != "object"].index
skewed_cols = full_data[num_cols].apply(lambda x: skew(x.dropna())).sort_values(ascending=False)

skewed_cols = skewed_cols[abs(skewed_cols) > 0.75]
skewed_features = skewed_cols.index
#lam = 0.15
for feat in skewed_features:
    full_data[feat] = boxcox1p(full_data[feat], boxcox_normmax(full_data[feat]+1))
#    full_data[feat] = boxcox1p(full_data[feat], lam)
#full_data[skewed_features] = np.log1p(full_data[skewed_features])

# get_dummies
cate_col = full_data.dtypes[full_data.dtypes == object].index
dummies_drop = [i + '_'+ full_data[i].value_counts().index[0] for i in cate_col]
full_data = pd.get_dummies(full_data)
full_data.drop(dummies_drop,axis=1)