import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
%matplotlib inline
plt.style.use('seaborn')
import seaborn as sns

from scipy.stats import norm, skew
from sklearn.preprocessing import StandardScaler, MinMaxScaler, MaxAbsScaler 
from scipy import stats
from scipy.special import boxcox1p
from scipy.stats import boxcox_normmax
from scipy.stats import zscore

dir(sklearn.ensemble) 				# Print methods
### Linear model ########################################################
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, HuberRegressor, LogisticRegression
								 SGDClassifier
# Linear regression
ols = LinearRegression()            # Use model name to check options in the model
hub = HuberRegressor() 				# Huber Regression without Removing the Outlier
ridge = Ridge(alpha=1.0, normalize=True)
lasso = Lasso()
elasticnet = ElasticNet(alpha=0.1, l1_ratio=0.5, normalize=False) # l1_ratio = 0 is Ridge
# Logistic regression
logit = LogisticRegression()        # C = n Regularization (C = 1/alpha)
sgd = SGDClassifier(loss='log', shuffle=False) # Stochastic Gradient Descent (shuffle = False is similar to gradient descent)

# General Attributes and Methods
.coef_  							# Estimated coefficients for the linear regression problem.
.intercept_							# Intercept term in the linear model.
.fit(X, y) 							# Fit linear model. X has to be an array with shape(-1,1) (X.reshape(-1,1))
.predict(X) 						# Predict using the linear model
.score(X, y) 						# Returns the coefficient of determination R**2 of the prediction.
.summary() 							# Print regression result table
.set_params() 						# set parameters of the model
.get_params() 

# RSS
np.sum((Y - ols.predict(X)) ** 2)
# Feature selection
lassoCoef = pd.Series(lasso.coef_, index=X.columns)
sortedCoefs = abs(lassoCoef).sort_values(ascending=False)

### Discriminant analysis ##############################
from sklearn import discriminant_analysis, naive_bayes

LDA = discriminant_analysis.LinearDiscriminantAnalysis()
QDA = discriminant_analysis.QuadraticDiscriminantAnalysis()
gnb = naive_bayes.GaussianNB()
mnb = naive_bayes.MultinomialNB()
bnb = naive_bayes.BernoulliNB()
# Attributes and Methods
.decision_function(X)				# Generate the decision boundaries 
.predict_proba(X) 					# Output the class probabilities
(store_covariance) 					# bool, whether to store covariance matrix
.covariance_  						# Output covariance

### Decision Tree #######################################
from sklearn import tree
tree_model = tree.DecisionTreeClassifier()

# Arguments
# criterion = "gini" or "entropy" , default = 'gini'
# max_depth = The maximum depth of the tree. default = None
# min_samples_split: The minimum number of samples required to split. default = 2.
# min_samples_leaf: The minimum number of samples required to be at a terminate node. default = 1.

# Methods
.predict_log_proba(X)				#  Predict class log-probabilities of the input samples X.

# Attributes
# tree_: Tree object, the underlying tree object.
# feature_importances_: The feature importances. The higher, the more important the feature. Also known as gini importance.

### Ensemble models ########################################
from sklearn import ensemble
randomForest = ensemble.RandomForestClassifier()
bagging      = ensemble.BaggingClassifier()
gbm 		 = ensemble.GradientBoostingRegressor()
gbm_c 		 = GradientBoostingClassifier()


# Hyperparameters
#max_depth: max tree height, default value 3
#max_leaf_nodes
#min_samples_leaf
#min_samples_split
#min_impurity_decrease
#min_impurity_split
#criterion: the criterion for tree splitting, defaulted to friedman_mse. friedman_mse is the same as mse (mean square error) when the loss function is chosen to be ls (least square)
#n_estimators: the number of trees, default value 100
#learning_rate: the shrinkage/discount factor, default value 0.1
#subsamples: the sample count in term of percentage used for a single tree training
#max_features: the integer or percentage count of the number of random feature selected for one tree node

.staged_predict: this method returns a generator. After kth next function call on the generator, it spits out the predicted values after k-th boosting iteration
.estimators_: it stores all the n_estimators trees used in building the boosting tree ensemble

### Support vector machine ##################################
from sklearn.svm import SVR, SVC
svm_model = SVC(kernel='poly', C=1e5, degree=1)  # kernel = linear, polynomial, rbf, sigmoid
svr = SVR(epsilon = 1e-4, gamma=1) 	# epsilon: paramter for epsilon-insensitive loss

# Arguments
# kernel: Specifies the kernel type to be used in the algorithm. 
# It must be one of ‘linear’, ‘poly’, ‘rbf’, ‘sigmoid’, ‘precomputed’ or a callable. 
# If none is given, ‘rbf’ will be used. If a callable is given, it is used to precompute the kernel matrix.
# C: Penalty parameter of the error term. C = 1 by default
# degree: Degree of the polynomial kernel function (‘poly’). Ignored by all other kernels.

# Attributes:
# support_: return the index of the support vectors.
# n_support_: return the number of support vectors.
# support_vectors_: return the value of support vectors.



## Cross Validation in Scikit-Learn (KFold,StratifiedKFold,train_test_split)
import sklearn.model_selection as ms
###############
ms_k3 = ms.KFold(n_splits=3)               # devide all the observation into k parts
ms_k3s = ms.StratifiedKFold(n_splits=3)    # each set contains approximately the same percentage of samples of each target class as the complete set.
x_train, x_test, y_train, y_test = ms.train_test_split(X, y, test_size=0.3, random_state=0)
# If we only want test error (score)
scores = ms.cross_val_score(estimator=ols/logit/ridge..., X=X, y=y, cv=5/ms_k3/ms_k3s, scoring='neg_mean_squared_error')
									  ^^^^ variables name              ^^^ # or variable name
###############
for train_idx, val_idx in ms_k3.split(sample): 				# For KFold
for train_idx, val_idx in ms_k3s.split(X=x, y=y):			# For StratifiedKFold
    print('Train:', train_idx, 'Validation:', val_idx)

# Example of cross validation
for train_idx, val_idx in ms_k3.split(sample):
    trX = sample[train_idx, ]
    teX = sample[val_idx, ]
    trY = Y[train_idx]
    teY = Y[val_idx]
    ols.fit(trX, trY)
    np.mean((teY - ols.predict(teX))**2)

# Grid Search
from sklearn.model_selection import GridSearchCV
para_names = [{
    "criterion": ["gini", "entropy"],
    "min_samples_leaf": range(1, 10),
    "min_samples_split": np.linspace(start=2, stop=30, num=15, dtype=int)
}]
#tree_model.set_params(random_state=108)
GS_name = GridSearchCV(model_name, para_names, cv=5, scoring='accuracy', n_jobs=-1)
GS_name.fit(x_train, y_train)

.best_params_       
.best_score_         # Return best score
.cv_results_         # Give CV results
.best_estimator_     # Return the model of best parameters

# Bootstrap
from sklearn.utils import resample
y_bs = resample(y,n_samples= n) 		# By default is the number of data
x_bs, y_bs = resample(x, y)

# Feature selection
# Remove features with low variance
import sklearn.feature_selection as fs
x_new = fs.VarianceThreshold(threshold = 1).fit_transform(X)
# Univariate Feature Selection
fs.chi2(X, Y)
# First row is chi2 statistics
# Second row is the corresponding p value

# confusion matrix
from sklearn.metrics import confusion_matrix
confusion_matrix(Y,logistic.predict(X))

#RSS Residual sum of square
np.sum((y_m - ols.predict(x_m)) ** 2)

# Import dataset from sklearn
from sklearn import datasets
boston = datasets.load_boston()
import pandas as pd
X_bos = pd.DataFrame(boston.data, columns=boston.feature_names)
y_bos = pd.Series(boston.target, name='MEDV')

# Categorical Input Variables
dummy = pd.get_dummies(pdSeries)	# Convert categorical variables (Series) 
# pd.get_dummies(df['RAD'], prefix='RAD', prefix_sep='__')
dummy.drop('Category', 1) 			# Drop one dummy variable

# Normalization of the Features
from sklearn.preprocessing import StandardScaler, MinMaxScaler, MaxAbsScaler 
scaler = StandardScaler()
scaler.fit(X_train)
X_train_scaled = scaler.transform(X_train)
X_test_scaled  = scaler.transform(X_test)
X_add_const = sm.add_constant(X_train_scaled)
ols = sm.OLS(y_train, X_add_const)
ans = ols.fit()

# Regularization plots example
alpha_100 = np.logspace(0, 8, 100)
coef = []
for i in alpha_100:
    ridge.set_params(alpha = i)
    ridge.fit(x, y)
    coef.append(ridge.coef_)

df_coef = pd.DataFrame(coef, index=alpha_100, columns=['TV', 'Radio', 'Newspaper'])
import matplotlib.pyplot as plt
title = 'Ridge coefficients as a function of the regularization'
axes = df_coef.plot(logx=True, title=title)
axes.set_xlabel('alpha')
axes.set_ylabel('coefficients')
plt.show()

# Up-Sampling the Minority Class
from sklearn.utils import resample
resampled = resample(Index_to_be_resample, n_samples = n)
LEFT = pd.DataFrame(list(cards.ID) + list(resampled), columns=['INDEX'])
cards2 = pd.merge(LEFT, cards, how='left', left_on ='INDEX', right_on='ID')

