# NumPy
import numpy as np
ary = np.array(list)
ary.dtype
ary[:,0] 	# The first element of each row

np.arange(start,end,step)						# Make an array from start to end-1 with step
np.linspace(start,end,number of elements)		# Make an n element array between start and end
np.ones(number of elements or [n,m])
np.zeros(number of elements)
np.diag(ary)
np.fliplr(ary) # Mirror maxtix
np.var(data, 0) 								# get variance of df 
np.argmax(x,axis=)								# Returns the indices of the maximum values along an axis
np.where(np.logical_and(X > 0, X < 0.5)) 		# Find index where ...
vectorized_func = np.vectorize(func) # To apply a func in array
vectorized_func(ary)
# Pointwise operations
+,-,*,/,**,%
# Change matrix shape
ary.shape # = (n,m) to reshape
ary.reshape([n,m])
# Logical operation
ary1 &| ary2 #(np.logical_and(ary1,ary2)),np.logical_or(ary1,ary2)
~ary1       # Not ary1
ary1.all() 	#The all operator outputs the logical_and between all the elements of a boolean array.
ary1.any()	#The any operator outputs the logical_or between all the elements of a boolean array.

# Matrix
mat = np.matrix(list)
mat.T 							# Transpose
mat.I 							# Inverse
mat1.dot(mat2) or mat1 * mat2	# Dot product 
mat1 @ mat2						# Dot product
np.eye(n)						# n x n identity matrix in array type. To transform the matrix np.matrix(np.eye(n))

# Random
The "numpy.random" submodule provides random number generator.
np.random.randn(dim0, dim1, ..., dn)	# Each entry is from the “standard normal” distribution.
np.random.rand(d0, d1, ..., dn) 		# Random array with a given shape where each element is from Uniform [0, 1].
np.random.randint(low, high, size)		# Random integers ranging from low (inclusive) to high (exclusive).
np.random.choice(a[], size, replace, p[])	# Generates a random sample from a given 1-D array. By default, replace=True.
												# p is the proability of each element in a. len(a) = len(p)

#Scipy
from scipy import stats
from sklearn import datasets

#Statistical Functions
stats.itemfreq(list)
stats.describe(dataset)		# Numerical features are summarized by the stats function describe()
stats.describe(dataset).minmax

# Pandas
import pandas as pd

# Series 							# 1D labeled homogeneously-typed array.
obj = pd.Series(list or dict, index = list) # Two lists must have same length
obj.index  							# Find index of the object
obj.items()							# Return tuple (key,values)
obj[key]=value 						# Adding new value
obj.values							# Return values as array
obj.to_dict()						# Convert series to dict
ogj.astype()

# DataFrame 						# General 2D labeled, size-mutable tabular structure with potentially heterogeneously-typed columns. 
df = pd.DataFrame(dict)				# Convert dict to DF {key:[items]}
df = pd.DataFrame(nested_list, 		# pd.DataFrame([[list]], columns=['a','b','c'])
             columns=[column_name]) 
df.shape 							# (rows,column)
df.head()							# Show first five rows
df.columns 
df.column_name.unique() 			# Show distinct values in that column
df.index  (=([4,5,6,7]))			# Call index (Customize index)
df.set_index(column_name)			# Use column_name as index (non-mutating) 
df.set_index(column_name, inplace = True) # Mutating
df.reset_index()
df.dtypes 							# Type of each column
df[column_names][n:m]				# This yields a pandas series 	then slicing
df[[column_names]][n:m]				# This yields a pandas data frame 	then slicing
#####################################
'''
langs = ["English" ,"French", "Mandarin"]
df.language.isin(langs)
df.imdb_score > 7
df[(df.language.isin(langs)) & (df.imdb_score > 7)]
''' 
#####################################
df.values							# Values (Properties)
df.columns (=list )					# Call column names (Rename columns)
df = df.rename({'a': 'X', 'b': 'Y'}, axis=1)
df.columns.tolist()
df.columns.value_counts() 			# Count the number of occ of each element in that column
#####################################
df.column_name						# Retrieve column values by attribute  
df.column_name.isin(list)			# Make a mask 
df.column_name >=< n 				
#####################################
df.columns.str.attribute
# I/O tools
df = pd.read_csv('name.csv')  		# By setting header = None, the column names will be filled with incremental numbers.
pd.set_option('display.max_columns', 50)
#, header = None, names = list) 	# Or set column names manually
pd.to_csv(file_name)

pd.concat([df1, df2], axis = 1,		# "axis = 1" means expanding along the column indices
		sort=True, join='inner')	# "axis = 0" will combine two data frames with same number of columns vertically
pd.sort_values(column_name,
		ascending=False)
# merge
pd.merge(df1, df2, how='inner', 	# how = 'left', 'outer'
	on =column_name)				# left_on='colA', right_on='colB'

# Selection and filter
df1[[col1,col2,...]]                # Select columns return df
df1[col1] = df1.col1				# Select columns return series (only work with one column)

df1.loc[index_name]					# Find the rows that has index_name				
df1.loc[index_name,column_names]	# the row that has index "index_name" and column "column_names"
df1.loc[df1.a==0,:]					# Retrun the rows with df1.a == 0
df1.iloc[1, 2]						# Select data by position number
df1.apply(func, axis=0)				# 0 stands for apply to each column, 1 stands for apply to each row (df1.apply(lambda x: max(x), axis=0))
df1.column_name.map(func)			# Apply the function to a single column
df1.drop('a', 1)					# Removes column 'a'
df1.loc[df1.index != 'two']			# Removes row 'two'

# Handling Missing Data
df.isnull()							# Figure out where the missing data is
np.sum(df.isnull())					# Summing up the boolean array reports how many missing values are in each column.
np.sum(df.isnull(), axis=1)			# Summing up the boolean array reports how many missing values are in each row.
mask = df.isnull().any(axis=1)		# Isolate the rows in which there are null values
mask = df.isnull().all(axis=1)		# Locate the rows that contains only missing values
df.loc[mask,:]						
df.replace('?',np.nan)				# Swap '?' with np.nan     ### df.replace(dict)
df.col.str.replace('a','b') 		# Replace 'a' with 'b' at specific column
df.dropna(axis=0, how='any/all')	# Discard the rows with missing values
df.fillna(value)					# Use value to replace nan
df[column_names].fillna(df[column_names].mean()) # Use mean of the column to replace nan
df.interpolate(method='linear')		

# Grouping
df[column_name].mean()
df[df[column_name]=='A'][column_name].sum()
df.groupby([column_names])[other_col_name] # select specific columns
group.size()						# The number of elements in each grouping
group.mean()						# Mean values for every coulumn in every grouping.
group.column_name.mean()
group.agg(['count', 'sum', 'min', 'max', 'mean', 'std',func])[column_name] # Apply multiple functions to each group [or column]
# agg({'col1':'mean','col2':['mean','count']})
#

# Time Series
df[date_column]=pd.to_datetime(date_column)
df.index.day
df.index.month
df.index.dayofweek
df.loc['5/2016']					# View all observations that occured in May 2016
df['5/3/2016':'5/4/2016']			# Observations between May 3rd and May 4th (inclusive)


# Matplotlib 
%matplotlib inline					# Display the graph inside IPython notebook

from matplotlib import pyplot as plt
plt.style.use('ggplot')

pd.set_option('display.max_columns', 50)
df.shape
df.describe()						# Return the statistics of numeric columns
df.language.value_counts()			# Get the statistics of a category column

# General
plt.plottype(color = 'green')
plt.axhline(y=0, alpha=0.3, ls='dashed')

# Labels
plt.xlabel('xlabel')
plt.ylabel('ylabel')
plt.xlim(0.0, 1.0)
plt.ylim(0.0, 1.0)
plt.legend(loc=1)
plt.title('title', fontsize=20)
plt.figure(figsize=(12,6))

# Histogram
plt.hist(df.column_name) 
or 
plt.hist(df['imdb_score']) 
or
df = np.log(df['column_name'])
df.plot.hist() 
or
df['column_name'].plot(kind='hist')

plt.hist(df.column_name, bins=20, color="#5ee3ff")
#plt.hist(np.log(df.budget[df.budget<=2.5e8]),bins=20)

# Scatterplot
plt.scatter(df['name1'], df['name2'])
df.plot(kind='scatter',x='column_name1', y='column_name2')
df.plot.scatter(x='budget', y='gross')
'''
scatter_df = df[['gross', 'budget']]
scatter_df = scatter_df.loc[scatter_df.apply(lambda x: np.abs(x - x.mean()) / x.std() < 3).all(axis=1)]
'''

# Barplot
df.plot.bar(color='b')
df.plot(kind='bar',color='b')

# Boxplot
df = df[['column_name1', 'column_name2']]
df.boxplot(by='column_name1', column='column_name2',figsize=(8,10))

# Line with equation 
plt.axvline(intercept_mean+2*intercept_std, c='r', alpha=0.3, linestyle='--')

# Seaborn
import seaborn as sns
b = sns.kdeplot(df['column_name'], shade=True, label='label')
sns.distplot(df['column_name'])
sns.boxplot(x='column_name1', y='column_name2', data=df)

b.tick_params(labelsize=12)
b.set_xlabel("Name",fontsize=14)















