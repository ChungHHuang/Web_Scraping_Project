### Linear model ########################################################
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, HuberRegressor, LogisticRegression
								 SGDClassifier
# Linear regression
ols = LinearRegression()            # Use model name to check options in the model
hub = HuberRegressor() 				# Huber Regression without Removing the Outlier
ridge = Ridge(alpha=1.0, normalize=True)
lasso = Lasso()
elasticnet = ElasticNet(alpha=0.1, l1_ratio=0.5, normalize=False) # l1_ratio = 0 is Ridge
# Logistic regression
logit = LogisticRegression()        # C = n Regularization (C = 1/alpha)
sgd = SGDClassifier(loss='log', shuffle=False) # Stochastic Gradient Descent (shuffle = False is similar to gradient descent)

# General Attributes and Methods
.coef_  							# Estimated coefficients for the linear regression problem.
.intercept_							# Intercept term in the linear model.
.fit(X, y) 							# Fit linear model. X has to be an array with shape(-1,1) (X.reshape(-1,1))
.predict(X) 						# Predict using the linear model
.score(X, y) 						# Returns the coefficient of determination R^2 of the prediction.
.summary() 							# Print regression result table
.set_params() 						# set parameters of the model
.get_params() 

# RSS
np.sum((Y - ols.predict(X)) ** 2)