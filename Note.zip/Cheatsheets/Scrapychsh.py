# cd to the folder that you want to create the scrapy folder
scrapy startproject NAMES

# Work flow
items.py -> name_spider.py -> pipelines.py -> settings.py
-> scrapy crawl NAME_spider
Set Indentation

# Template
# Items
import scrapy
class NameItem(scrapy.Item):
    a = scrapy.Field()
    b = scrapy.Field()
    c = scrapy.Field()
    d = scrapy.Field()


#######################Selectors######################
https://doc.scrapy.org/en/latest/topics/selectors.html
######################################################
###### Xpath #########
Single slash / means a direct child of the current tag.
Double slash // means any descendant tag of the current tag in the html tree which feets the locator.
Dot . refers to the current tag.
# Examples
/html/head/title selects the <title> tag inside a <head> tag of an HTML tag.
//tr selects all the <tr> tags from the html tag.
./td[2] select the second td tag after the current tag XPath start counting from 1 rather than 0.

--  @ find the tag with certain attribute(s)
    //div[@class="mine"] selects all the <div> tags having an attribute class="mine"
    //div[@itemprop="some_prop" and @class="some_class"] selects all the <div> tags having both attributes

--  * will find any type of tag that match the xpath
    //*[@class="mine"] select all the tags including <div>, <p>...

To select the text of a tag, add /text() at the end of the expression
    //div[@class="mine"]/text()

To select any attribute of a tag, add /@name_of_attribute at the end of the expression
    //div[@class="mine"]/@itemprop

###### scrapy shell ######
scrapy shell "url_of_the_page_you're_scraping"
scrapy shell -s USER_AGENT='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36' "url_of_the_page_you're_scraping"
USER_AGENT = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'

response.xpath('//*[@id="mw-content-text"]/div/table/tbody/tr')
rows=response.xpath('//*[@id="mw-content-text"]/div/table/tbody/tr') <= copy this to NAMESpider class
print(len(rows))

########### spider.py ###########
from scrapy import Spider #, Request
from NAME.items import NAMEItem
# If needed
import re  

class NAMESpider(Spider):
    name = 'NAME_spider' #<===== This is the name to crawl
    allowed_urls = ['https://']
    start_urls = ['https://']

    def parse(self, response): #Figure out number of items
        num_prods = response.xpath('//div[@class="footer top-border wrapper"]/div[@class="left-side"]/span/text()').extract_first()
        per_page, total_prod = map(int,re.findall('\d-(\d+) of (\d+)',num_prods)[0])

        # if total_prod%per_page == 0:
        #     total_pages = total_prod//per_page
        # else:
        #     total_pages = total_prod//per_page + 1

        # Obtain the url for all laptops (observe the pattern)
        url_list = ['https://www.bestbuy.com/site/all-laptops/pc-laptops/pcmcat247400050000.c?cp={}&id=pcmcat247400050000'.format(i+1) for i in range(total_pages)]

        # Link to specific product page
        for url in url_list[:3]:
            yield Request(url=url, callback=self.parse_result_page)

    def parse_result_page(self, response):
        # Find the url of laptops
        product_urls = response.xpath('//h4[@class="sku-header"]/a/@href').extract()
        product_urls = ['https://www.bestbuy.com' + s for s in product_urls]

        ''' 
        First check point (Check if we get number of urls right)
        print('='*50)
        print(len(product_urls))
        print('='*50)
        '''
        for url in product_urls:
            yield Request(url=url, callback=self.parse_detail_page)

    def parse_detail_page(self, response):
        # Go to all costumer reviews
        first_review_page = response.xpath('//div[@class="col-xs-12"]/a/@href').extract_first()
        try: # Bring the numbers of answered question to the next level through 'meta'
            questions = response.xpath('//div[@class="ugc-qna-stats ugc-stat"]/a/text()').extract_first()
            questions = int(re.findall('\d+',questions)[0])
        except:
            questions = 0

        yield Request(url='https://www.bestbuy.com'+first_review_page, 
                        meta={'questions': questions}, 
                        callback=self.parse_review_page)

    def parse_review_page(self, response):
        questions = response.meta['questions']
        reviews =  response.xpath('//li[@class="review-item"]')

        '''
        Second checkpoint
        print('=' * 50)
        print(questions)
        print(len(reviews))
        print('=' * 50)
        '''

        for review in reviews:

            user = review.xpath('.//div[@class="undefined ugc-author v-fw-medium body-copy-lg"]/text()').extract_first()
            rating = int(review.xpath('.//span[@class="c-review-average"]/text()').extract_first())
            title = review.xpath('.//h3[@class="ugc-review-title c-section-title heading-5 v-fw-medium  "]/text()').extract_first()
            product = review.xpath('//h2[@class="product-title"]/a/text()').extract_first()
            text = review.xpath('.//p[@class="pre-white-space"]/text()').extract_first()
            try:
                helpful = review.xpath('.//button[@data-track="Helpful"]/text()').extract()[1]
            except IndexError:
                helpful = ""
            try:
                unhelpful = review.xpath('.//button[@data-track="Unhelpful"]/text()').extract()[1]
            except IndexError:
                unhelpful = ""

            item = BestbuyItem
            item['user'] = user
            item['rating'] = rating
            item['title'] = title
            item['text'] = text
            item['helpful'] = helpful
            item['unhelpful'] = unhelpful
            item['product'] = product
            yield item

############# Pipeline ################
from scrapy.exceptions import DropItem
from scrapy.exporters import CsvItemExporter

class ValidateItemPipeline(object):

    def process_item(self, item, spider):
        if not all(item.values()):
            raise DropItem("Missing values!")
        else:
            return item

class WriteItemPipeline(object):

    def __init__(self):
        self.filename = 'NAME.csv'

    def open_spider(self, spider):
        self.csvfile = open(self.filename, 'wb')
        self.exporter = CsvItemExporter(self.csvfile)
        self.exporter.start_exporting()

    def close_spider(self, spider):
        self.exporter.finish_exporting()
        self.csvfile.close()

    def process_item(self, item, spider):
        self.exporter.export_item(item)
        return item

############## Settings ################
ITEM_PIPELINES = {'NAME.pipelines.ValidateItemPipeline': 100, 
                    'NAME.pipelines.WriteItemPipeline': 200}



